-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- 主機: localhost
-- 建立日期: Jun 16, 2013, 07:02 PM
-- 伺服器版本: 5.0.51
-- PHP 版本: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- 資料庫: `sweet`
-- 

-- --------------------------------------------------------

-- 
-- 資料表格式： `sweetlist`
-- 

CREATE TABLE `sweetlist` (
  `name` text NOT NULL,
  `sweetname` text NOT NULL,
  `material` text NOT NULL,
  `make` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- 列出以下資料庫的數據： `sweetlist`
-- 

INSERT INTO `sweetlist` VALUES ('正咩', '甜甜圈', '麵粉、糖', '作成甜甜圈');
INSERT INTO `sweetlist` VALUES ('陳昱安', '奶酪', '牛奶', '作成奶酪');
